package com.example.ev2;

public class Departamento {
    private String nombreDepartamento;
    private Empleado gerente;

    // Constructor
    public Departamento(String nombreDepartamento, Empleado gerente) {
        this.nombreDepartamento = nombreDepartamento;
        this.gerente = gerente;
    }

    // Getters
    public String getNombreDepartamento() {
        return nombreDepartamento;
    }

    public Empleado getGerente() {
        return gerente;
    }

    // Setters
    public void setNombreDepartamento(String nombreDepartamento) {
        this.nombreDepartamento = nombreDepartamento;
    }

    public void setGerente(Empleado gerente) {
        this.gerente = gerente;
    }
}
