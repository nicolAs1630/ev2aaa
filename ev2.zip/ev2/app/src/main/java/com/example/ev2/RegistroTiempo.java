package com.example.ev2;

public class RegistroTiempo {
    private String fecha;
    private double horasTrabajadas;
    private String descripcionTarea;
    private Proyecto proyecto;

    // Constructor
    public RegistroTiempo(String fecha, double horasTrabajadas, String descripcionTarea, Proyecto proyecto) {
        this.fecha = fecha;
        this.horasTrabajadas = horasTrabajadas;
        this.descripcionTarea = descripcionTarea;
        this.proyecto = proyecto;
    }

    // Getters
    public String getFecha() {
        return fecha;
    }

    public double getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public String getDescripcionTarea() {
        return descripcionTarea;
    }

    public Proyecto getProyecto() {
        return proyecto;
    }

    // Setters
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setHorasTrabajadas(double horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public void setDescripcionTarea(String descripcionTarea) {
        this.descripcionTarea = descripcionTarea;
    }

    public void setProyecto(Proyecto proyecto) {
        this.proyecto = proyecto;
    }
}
