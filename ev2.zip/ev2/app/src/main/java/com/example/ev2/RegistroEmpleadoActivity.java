package com.example.ev2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class RegistroEmpleadoActivity extends AppCompatActivity {
    ArrayList<Empleado> empleados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_empleado);

        EditText etIdEmpleado = findViewById(R.id.etIdEmpleado);
        EditText etNombre = findViewById(R.id.etNombre);
        EditText etDireccion = findViewById(R.id.etDireccion);
        EditText etTelefono = findViewById(R.id.etTelefono);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etFechaInicio = findViewById(R.id.etFechaInicio);
        EditText etSalario = findViewById(R.id.etSalario);
        Button btnRegistrarEmpleado = findViewById(R.id.btnRegistrarEmpleado);

        btnRegistrarEmpleado.setOnClickListener(view -> {
            String idEmpleado = etIdEmpleado.getText().toString();
            String nombre = etNombre.getText().toString();
            String direccion = etDireccion.getText().toString();
            String telefono = etTelefono.getText().toString();
            String email = etEmail.getText().toString();
            String fechaInicio = etFechaInicio.getText().toString();
            double salario = Double.parseDouble(etSalario.getText().toString());

            // Crear nuevo empleado con los datos obtenidos
            Empleado nuevoEmpleado = new Empleado(idEmpleado, nombre, direccion, telefono, email, fechaInicio, salario);
            empleados.add(nuevoEmpleado);

            Toast.makeText(RegistroEmpleadoActivity.this, "Empleado registrado", Toast.LENGTH_SHORT).show();
        });
    }
}
