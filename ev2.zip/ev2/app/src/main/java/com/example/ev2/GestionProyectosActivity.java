package com.example.ev2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class GestionProyectosActivity extends AppCompatActivity {
    ArrayList<Proyecto> proyectos = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_proyectos);

        EditText etNombreProyecto = findViewById(R.id.etNombreProyecto);
        EditText etDescripcionProyecto = findViewById(R.id.etDescripcionProyecto);
        EditText etFechaInicio = findViewById(R.id.etFechaInicio);
        Button btnCrearProyecto = findViewById(R.id.btnCrearProyecto);

        btnCrearProyecto.setOnClickListener(view -> {
            String nombreProyecto = etNombreProyecto.getText().toString();
            String descripcion = etDescripcionProyecto.getText().toString();
            String fechaInicio = etFechaInicio.getText().toString();

            Proyecto nuevoProyecto = new Proyecto(nombreProyecto, descripcion, fechaInicio);
            proyectos.add(nuevoProyecto);
            Toast.makeText(GestionProyectosActivity.this, "Proyecto creado", Toast.LENGTH_SHORT).show();
        });
    }
}