package com.example.ev2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class RegistroTiempoActivity extends AppCompatActivity {
    ArrayList<Proyecto> proyectos = new ArrayList<>();
    ArrayList<RegistroTiempo> registrosTiempo = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_tiempo);

        EditText etNombreProyecto = findViewById(R.id.etNombreProyecto);
        EditText etFecha = findViewById(R.id.etFecha);
        EditText etHorasTrabajadas = findViewById(R.id.etHorasTrabajadas);
        EditText etDescripcionTarea = findViewById(R.id.etDescripcionTarea);
        Button btnRegistrarTiempo = findViewById(R.id.btnRegistrarTiempo);

        btnRegistrarTiempo.setOnClickListener(view -> {
            String nombreProyecto = etNombreProyecto.getText().toString();
            String fecha = etFecha.getText().toString();
            double horasTrabajadas = Double.parseDouble(etHorasTrabajadas.getText().toString());
            String descripcionTarea = etDescripcionTarea.getText().toString();

            // Encontrar el proyecto por nombre
            Proyecto proyectoEncontrado = null;
            for (Proyecto proyecto : proyectos) {
                if (proyecto.getNombreProyecto().equals(nombreProyecto)) {
                    proyectoEncontrado = proyecto;
                    break;
                }
            }

            if (proyectoEncontrado != null) {
                // Crear un nuevo registro de tiempo
                RegistroTiempo nuevoRegistro = new RegistroTiempo(fecha, horasTrabajadas, descripcionTarea, proyectoEncontrado);
                registrosTiempo.add(nuevoRegistro);

                Toast.makeText(RegistroTiempoActivity.this, "Tiempo registrado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(RegistroTiempoActivity.this, "Proyecto no encontrado", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
