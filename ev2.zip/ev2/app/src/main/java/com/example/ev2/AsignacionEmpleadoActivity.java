package com.example.ev2;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.ev2.Departamento;
import java.util.ArrayList;

public class AsignacionEmpleadoActivity extends AppCompatActivity {
    ArrayList<Empleado> empleados;  // Lista de empleados
    ArrayList<Departamento> departamentos;  // Lista de departamentos

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asignacion_empleado);

        EditText etIdEmpleado = findViewById(R.id.etIdEmpleado);
        EditText etNombreDepartamento = findViewById(R.id.etNombreDepartamento);
        Button btnAsignarEmpleado = findViewById(R.id.btnAsignarEmpleado);

        empleados = new ArrayList<>(); // Aquí se obtiene la lista de empleados
        departamentos = new ArrayList<>(); // Aquí se obtiene la lista de departamentos

        btnAsignarEmpleado.setOnClickListener(view -> {
            String idEmpleado = etIdEmpleado.getText().toString();
            String nombreDepartamento = etNombreDepartamento.getText().toString();

            Empleado empleado = buscarEmpleadoPorId(idEmpleado);
            Departamento departamento = buscarDepartamentoPorNombre(nombreDepartamento);

            if (empleado != null && departamento != null) {
                // Aquí puedes realizar la lógica de asignación
                Toast.makeText(AsignacionEmpleadoActivity.this, "Empleado asignado al departamento", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(AsignacionEmpleadoActivity.this, "Empleado o Departamento no encontrado", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private Empleado buscarEmpleadoPorId(String id) {
        for (Empleado empleado : empleados) {
            if (empleado.getIdEmpleado().equals(id)) {
                return empleado;
            }
        }
        return null;
    }

    private Departamento buscarDepartamentoPorNombre(String nombre) {
        for (Departamento departamento : departamentos) {
            if (departamento.getNombreDepartamento().equals(nombre)) {
                return departamento;
            }
        }
        return null;
    }
}
