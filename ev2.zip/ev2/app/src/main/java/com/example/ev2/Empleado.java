package com.example.ev2;

public class Empleado {
    private String idEmpleado;
    private String nombre;
    private String direccion;
    private String telefono;
    private String email;
    private String fechaInicio;
    private double salario;

    // Constructor
    public Empleado(String idEmpleado, String nombre, String direccion, String telefono, String email, String fechaInicio, double salario) {
        this.idEmpleado = idEmpleado;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.fechaInicio = fechaInicio;
        this.salario = salario;
    }

    // Getters
    public String getIdEmpleado() {
        return idEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public double getSalario() {
        return salario;
    }

    // Setters
    public void setIdEmpleado(String idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
}
