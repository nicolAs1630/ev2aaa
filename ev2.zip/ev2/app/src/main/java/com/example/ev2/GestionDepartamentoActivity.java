package com.example.ev2;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.ev2.Empleado;
import com.example.ev2.Departamento;
import java.util.ArrayList;

public class GestionDepartamentoActivity extends AppCompatActivity{
    ArrayList<Departamento> departamentos = new ArrayList<>();
    ArrayList<Empleado> empleados; // Lista de empleados para asociar el gerente

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_departamento);

        EditText etNombreDepartamento = findViewById(R.id.etNombreDepartamento);
        EditText etGerente = findViewById(R.id.etGerente);
        Button btnAgregarDepartamento = findViewById(R.id.btnAgregarDepartamento);

        // Recupera los empleados de alguna fuente (enlace a otro Intent)
        empleados = new ArrayList<>(); // aquí se puede obtener la lista de empleados

        btnAgregarDepartamento.setOnClickListener(view -> {
            String nombreDepartamento = etNombreDepartamento.getText().toString();
            String idGerente = etGerente.getText().toString();
            Empleado gerente = buscarEmpleadoPorId(idGerente);

            if (gerente != null){
                Departamento nuevoDepartamento = new Departamento(nombreDepartamento, gerente);
                departamentos.add(nuevoDepartamento);
                Toast.makeText(GestionDepartamentoActivity.this, "Departamento agregado", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(GestionDepartamentoActivity.this, "Gerente no encontrado", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private Empleado buscarEmpleadoPorId(String id){
        for (Empleado empleado: empleados){
            if (empleado.getIdEmpleado().equals(id)){
                return empleado;
            }
        }
        return null;
    }
}
